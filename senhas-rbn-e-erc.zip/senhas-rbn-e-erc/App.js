import React, { useState } from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function App() {
  // estado para armazenar os contadores de cada tipo de senha
  const [normalCount, setNormalCount] = useState(1);
  const [prioritarioCount, setPrioritarioCount] = useState(1);
  const [altaPrioridadeCount, setAltaPrioridadeCount] = useState(1);

  // estado para armazenar a senha gerada
  const [senhaGerada, setSenhaGerada] = useState('');

  // gerar senha normal
  const gerarSenhaNormal = () => {
    const senha = `N${normalCount < 10 ? '0' : '' || normalCount >= 10 ? '0' : ''}${normalCount}`;
    setSenhaGerada(senha);
    setNormalCount(normalCount + 1);
  };

  // para gerar senha prioritária
  const gerarSenhaPrioritario = () => {
    const senha = `P${prioritarioCount < 10 ? '0' : ''}${prioritarioCount}`;
    setSenhaGerada(senha);
    setPrioritarioCount(prioritarioCount + 1);
  };

  // gerar senha de alta prioridade
  const gerarSenhaAltaPrioridade = () => {
    const senha =
      altaPrioridadeCount < 10
        ? `AP00${altaPrioridadeCount}`
        : `AP0${altaPrioridadeCount}`;
    setSenhaGerada(senha);
    setAltaPrioridadeCount(altaPrioridadeCount + 1);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Gerador de Senhas de Atendimento</Text>

      <View style={styles.buttonContainer}>
        <Button title="Senha Normal" onPress={gerarSenhaNormal} />
        <Button title="Senha Prioritária" onPress={gerarSenhaPrioritario} />
        <Button title="Senha Alta Prioridade" onPress={gerarSenhaAltaPrioridade} />
      </View>

      {senhaGerada ? (
        <View style={styles.resultContainer}>
          <Text style={styles.result}>Senha Gerada: {senhaGerada}</Text>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    padding: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  buttonContainer: {
    marginBottom: 30,
  },
  resultContainer: {
    marginTop: 20,
    padding: 10,
    backgroundColor: '#e0e0e0',
    borderRadius: 5,
  },
  result: {
    fontSize: 18,
    fontWeight: '500',
  },
});